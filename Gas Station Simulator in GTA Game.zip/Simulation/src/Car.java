class Car {
    private String type;
    private int fuelCapacity;
    private int currentFuel;
    private String fuelType;
    private int wallet;

    public Car(String type, int fuelCapacity, int currentFuel, String fuelType, int wallet) {
        this.type = type;
        this.fuelCapacity = fuelCapacity;
        this.currentFuel = currentFuel;
        this.fuelType = fuelType;
        this.wallet = wallet;
    }

    public String getType() {
        return type;
    }

    public int getFuelCapacity() {
        return fuelCapacity;
    }

    public int getCurrentFuel() {
        return currentFuel;
    }

    public String getFuelType() {
        return fuelType;
    }

    public int getWallet() {
        return wallet;
    }

    public void setCurrentFuel(int fuel) {
        this.currentFuel = fuel;
    }

    public void setWallet(int amount) {
        this.wallet = amount;
    }
}