import java.io.*;
import java.time.LocalTime;
import java.util.*;

class GasStation {
    private List<FuelPump> fuelPumps;
    private Queue<Car> carQueue;

    public GasStation(List<FuelPump> fuelPumps, Queue<Car> carQueue) {
        this.fuelPumps = fuelPumps;
        this.carQueue = carQueue;
    }

    public void startSimulation() throws InterruptedException, IOException {
        while (!carQueue.isEmpty()) {
            Car car = carQueue.poll(); // خودرو رو از صف خارج میکنه
            for (FuelPump pump : fuelPumps) {
                if (pump.getFuelType().equals(car.getFuelType())) {
                    if (pump.getCapacity() >= (car.getFuelCapacity() - car.getCurrentFuel())) {
                        int fuelNeeded = car.getFuelCapacity() - car.getCurrentFuel();
                        logEvent("Car with fuel capacity " + car.getFuelCapacity() + " is about to start refueling at " + LocalTime.now());
                        pump.setCapacity(pump.getCapacity() - fuelNeeded);
                        car.setCurrentFuel(car.getFuelCapacity());
                        int cost = fuelNeeded * getFuelPrice(pump.getFuelType());
                        car.setWallet(car.getWallet() - cost);
                        logEvent("The car's capacity after refueling => " + car.getCurrentFuel() + " at " + LocalTime.now());
                        logPayment(cost);
                        Thread.sleep(fuelNeeded * 40); // توقف برای سوخت گیری
                    } else {
                        logEvent("Pump capacity is not enough, refilling pump at " + LocalTime.now());
                        try {
                            pump.refill(); // تلاش برای شارژ مججد جایگاه
                            carQueue.add(car); // اضافه کردن خورو به صف
                        } catch (Exception e) {
                            logEvent("Failed to refill pump: " + e.getMessage() + " at " + LocalTime.now());
                        }
                    }
                    break;
                } else {
                    logEvent("This station is not compatible to this car at " + LocalTime.now());
                }
            }
        }
    }

    private int getFuelPrice(String fuelType) {
        switch (fuelType) {
            case "regular":
                return 1000;
            case "supreme":
                return 1500;
            case "euro4":
                return 2000;
            default:
                return 0;
        }
    }

    private void logEvent(String message) throws IOException {
        try (FileWriter writer = new FileWriter("logs.txt", true)) {
            writer.write(message + "\n");
        }
    }

    private void logPayment(int amount) throws IOException {
        try (FileWriter writer = new FileWriter("payments.txt", true)) {
            writer.write("Payment: " + amount + " units\n");
        }
    }
}