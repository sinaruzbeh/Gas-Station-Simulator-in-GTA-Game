import java.io.*;
import java.util.*;


public class Simulation {
    public static void main(String[] args) throws InterruptedException, IOException {
        Scanner scanner = new Scanner(System.in);
        List<FuelPump> fuelPumps = Arrays.asList(
                new FuelPump("regular", 150, 500),
                new FuelPump("supreme", 150, 500),
                new FuelPump("euro4", 150, 500)
        );
        Queue<Car> carQueue = new LinkedList<>();

        System.out.println("Enter numbers of cars:");
        int carCount = scanner.nextInt();
        for (int i = 0; i < carCount; i++) {
            System.out.println("Enter a car type between (A, B, C):");
            String type = scanner.next();
            System.out.println("Enter current fuel of the car:");
            int currentFuel = scanner.nextInt();
            System.out.println("Enter wallet amount of the car:");
            int wallet = scanner.nextInt();
            switch (type) {
                case "A":
                    carQueue.add(new Car("A", 80, currentFuel, "regular", wallet));
                    break;
                case "B":
                    carQueue.add(new Car("B", 70, currentFuel, "supreme", wallet));
                    break;
                case "C":
                    carQueue.add(new Car("C", 60, currentFuel, "euro4", wallet));
                    break;
            }
        }

        GasStation gasStation = new GasStation(fuelPumps, carQueue);

        while (true) {
            System.out.println("1. Start simulating");
            System.out.println("2. Show management report");
            System.out.println("3. Show the latest simulation logs");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    gasStation.startSimulation();
                    break;
                case 2:
                    showManagementReport();
                    break;
                case 3:
                    showLogs();
                    break;
                default:
                    System.out.println("Invalid select, please try again.");
            }
        }
    }

    private static void showManagementReport() throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader("payments.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (FileNotFoundException e) {
            System.out.println("management report did not found.");
        }
    }

    private static void showLogs() throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader("logs.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (FileNotFoundException e) {
            System.out.println("No logs did not found.");
        }
    }
}