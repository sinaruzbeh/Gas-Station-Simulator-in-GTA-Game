class FuelPump {
    private String fuelType;
    private int capacity;
    private int tankCapacity;

    public FuelPump(String fuelType, int capacity, int tankCapacity) {
        this.fuelType = fuelType;
        this.capacity = capacity;
        this.tankCapacity = tankCapacity;
    }

    public String getFuelType() {
        return fuelType;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getTankCapacity() {
        return tankCapacity;
    }

    public void refill() throws InterruptedException {
        if (tankCapacity > 0) {
            Thread.sleep(2000);
            int refillAmount = Math.min(150, tankCapacity);
            this.capacity += refillAmount;
            this.tankCapacity -= refillAmount;
        } else {
            throw new RuntimeException("Tank is empty, cannot refill");
        }
    }
}